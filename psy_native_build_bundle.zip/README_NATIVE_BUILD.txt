PSY Native Build Bundle

Files:
- psy_bubble_app.py
- build_windows_exe.bat
- build_macos_app.sh
- requirements.txt

Usage on Windows:
1. Install Python 3
2. Open Command Prompt in this folder
3. Run:
   pip install -r requirements.txt
   build_windows_exe.bat

Usage on macOS:
1. Install Python 3
2. Open Terminal in this folder
3. Run:
   pip3 install -r requirements.txt
   chmod +x build_macos_app.sh
   bash build_macos_app.sh

Build output:
- Windows: dist/PSY Bubble Detection App.exe
- macOS: dist/PSY Bubble Detection App.app