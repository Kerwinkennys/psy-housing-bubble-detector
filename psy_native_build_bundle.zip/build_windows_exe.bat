@echo off
cd /d "%~dp0"
if not exist psy_bubble_app.py (
  echo psy_bubble_app.py not found in this folder.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --windowed --name "PSY Bubble Detection App" psy_bubble_app.py
if %errorlevel% neq 0 (
  py -m PyInstaller --noconfirm --windowed --name "PSY Bubble Detection App" psy_bubble_app.py
)
echo.
echo Build finished. Check the dist folder.
pause
