#!/bin/bash
cd "$(dirname "$0")"
if [ ! -f "psy_bubble_app.py" ]; then
  echo "psy_bubble_app.py not found in this folder."
  exit 1
fi

if command -v python3 >/dev/null 2>&1; then
  python3 -m PyInstaller --noconfirm --windowed --name "PSY Bubble Detection App" psy_bubble_app.py
elif command -v python >/dev/null 2>&1; then
  python -m PyInstaller --noconfirm --windowed --name "PSY Bubble Detection App" psy_bubble_app.py
else
  echo "Python not found."
  exit 1
fi

echo
echo "Build finished. Check the dist folder."
