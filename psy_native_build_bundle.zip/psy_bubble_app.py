
import math
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

APP_TITLE = "PSY Bubble Detection App"

# -----------------------------
# Core econometric functions
# -----------------------------
def adf_tstat_right_tailed(y_window: np.ndarray, lags: int = 0) -> float:
    """
    Compute right-tailed ADF t-statistic on a given window.
    Model:
        Δy_t = α + β y_{t-1} + sum(phi_i Δy_{t-i}) + ε_t
    Returns the t-statistic for β.
    """
    y_window = np.asarray(y_window, dtype=float)
    if len(y_window) < max(10, lags + 5):
        return np.nan

    dy = np.diff(y_window)
    y_lag = y_window[:-1]  # y_{t-1}

    # Base regressors: intercept + y_{t-1}
    X_parts = [np.ones(len(dy)), y_lag]

    # Add lagged differences if needed
    if lags > 0:
        for i in range(1, lags + 1):
            lagged_dy = np.concatenate([np.full(i, np.nan), dy[:-i]])
            X_parts.append(lagged_dy)

    X = np.column_stack(X_parts)
    Y = dy

    # Drop rows with NaN caused by lagging
    valid = ~np.isnan(X).any(axis=1)
    X = X[valid]
    Y = Y[valid]

    n, k = X.shape
    if n <= k + 1:
        return np.nan

    # OLS
    XtX = X.T @ X
    try:
        XtX_inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        return np.nan

    beta_hat = XtX_inv @ (X.T @ Y)
    resid = Y - X @ beta_hat
    sigma2 = (resid @ resid) / (n - k)
    var_beta = sigma2 * XtX_inv
    se_beta = np.sqrt(np.diag(var_beta))

    # β coefficient is index 1 (intercept at 0, y_{t-1} at 1)
    if se_beta[1] == 0 or np.isnan(se_beta[1]):
        return np.nan
    t_stat = beta_hat[1] / se_beta[1]
    return float(t_stat)


def compute_bsadf(log_price: np.ndarray, min_window: int, lags: int = 0):
    """
    Compute BSADF sequence for a single series.

    For each end point r2, compute the supremum of right-tailed ADF
    over all possible starting points, subject to minimum window length.
    """
    T = len(log_price)
    bsadf = np.full(T, np.nan)

    for end_idx in range(min_window - 1, T):
        stats = []
        for start_idx in range(0, end_idx - min_window + 2):
            y_window = log_price[start_idx:end_idx + 1]
            stat = adf_tstat_right_tailed(y_window, lags=lags)
            if np.isfinite(stat):
                stats.append(stat)
        if stats:
            bsadf[end_idx] = np.nanmax(stats)

    return bsadf


def monte_carlo_critical_values(T: int, min_window: int, lags: int, simulations: int, seed: int = 42, progress_cb=None):
    """
    Generate 95% Monte Carlo critical value sequence using simulated random walks.
    """
    rng = np.random.default_rng(seed)
    all_bsadf = np.full((simulations, T), np.nan)

    for i in range(simulations):
        eps = rng.normal(0, 1, T)
        rw = np.cumsum(eps)  # random walk
        bsadf_sim = compute_bsadf(rw, min_window=min_window, lags=lags)
        all_bsadf[i, :] = bsadf_sim
        if progress_cb and ((i + 1) % max(1, simulations // 100) == 0 or i == simulations - 1):
            progress_cb(i + 1, simulations)

    crit_95 = np.nanpercentile(all_bsadf, 95, axis=0)
    return crit_95


def detect_bubble_episodes(date_index: pd.Series, bsadf: np.ndarray, critical: np.ndarray, min_duration: int = 3):
    """
    Identify continuous periods where BSADF > critical value.
    """
    above = np.isfinite(bsadf) & np.isfinite(critical) & (bsadf > critical)
    episodes = []
    start = None

    for i, flag in enumerate(above):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            end = i - 1
            duration = end - start + 1
            if duration >= min_duration:
                peak_idx = start + int(np.nanargmax(bsadf[start:end+1]))
                episodes.append({
                    "Start Date": pd.to_datetime(date_index.iloc[start]).strftime("%Y-%m"),
                    "End Date": pd.to_datetime(date_index.iloc[end]).strftime("%Y-%m"),
                    "Duration (months)": duration,
                    "Peak BSADF": float(np.nanmax(bsadf[start:end+1])),
                    "Peak Date": pd.to_datetime(date_index.iloc[peak_idx]).strftime("%Y-%m"),
                })
            start = None

    if start is not None:
        end = len(above) - 1
        duration = end - start + 1
        if duration >= min_duration:
            peak_idx = start + int(np.nanargmax(bsadf[start:end+1]))
            episodes.append({
                "Start Date": pd.to_datetime(date_index.iloc[start]).strftime("%Y-%m"),
                "End Date": pd.to_datetime(date_index.iloc[end]).strftime("%Y-%m"),
                "Duration (months)": duration,
                "Peak BSADF": float(np.nanmax(bsadf[start:end+1])),
                "Peak Date": pd.to_datetime(date_index.iloc[peak_idx]).strftime("%Y-%m"),
            })

    return episodes


# -----------------------------
# Data handling
# -----------------------------
def load_price_file(path: str) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path)

    required = {"Year", "Month"}
    if not required.issubset(set(df.columns)):
        raise ValueError("Input file must contain 'Year' and 'Month' columns.")
    df = df.copy()
    df["Date"] = pd.to_datetime(dict(year=df["Year"].astype(int), month=df["Month"].astype(int), day=1))
    df = df.sort_values("Date").reset_index(drop=True)
    return df


def preprocess_series(series: pd.Series) -> np.ndarray:
    s = pd.to_numeric(series, errors="coerce").interpolate(method="linear", limit_direction="both")
    if (s <= 0).any():
        raise ValueError("Series contains non-positive values; log transformation is not possible.")
    return np.log(s.to_numpy(dtype=float))


# -----------------------------
# Reporting and plotting
# -----------------------------
def save_city_plot(out_path: Path, city: str, dates: pd.Series, bsadf: np.ndarray, critical: np.ndarray):
    fig, ax = plt.subplots(figsize=(12, 6), dpi=300)
    ax.plot(dates, bsadf, label="BSADF statistic", linewidth=1.8)
    ax.plot(dates, critical, label="95% Monte Carlo critical value", linewidth=1.5)

    above = np.isfinite(bsadf) & np.isfinite(critical) & (bsadf > critical)
    if above.any():
        in_run = False
        run_start = None
        for i, flag in enumerate(above):
            if flag and not in_run:
                in_run = True
                run_start = i
            elif not flag and in_run:
                ax.axvspan(dates.iloc[run_start], dates.iloc[i - 1], alpha=0.15)
                in_run = False
        if in_run:
            ax.axvspan(dates.iloc[run_start], dates.iloc[len(dates)-1], alpha=0.15)

    ax.set_title(f"PSY Bubble Detection: {city}")
    ax.set_xlabel("Date")
    ax.set_ylabel("Statistic")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def write_outputs(df: pd.DataFrame, results: dict, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)

    # Summary and episodes
    summary_rows = []
    episode_rows = []

    for city, res in results.items():
        bsadf = res["bsadf"]
        critical = res["critical"]
        dates = df["Date"]
        episodes = detect_bubble_episodes(dates, bsadf, critical, min_duration=res["min_duration"])

        summary_rows.append({
            "City": city,
            "Observations": len(dates),
            "Minimum Window (months)": res["min_window"],
            "Lag Length": res["lags"],
            "Monte Carlo Simulations": res["simulations"],
            "Number of Episodes": len(episodes),
            "Peak BSADF": float(np.nanmax(bsadf)) if np.isfinite(bsadf).any() else np.nan
        })

        if episodes:
            for i, ep in enumerate(episodes, 1):
                row = {"City": city, "Episode No.": i}
                row.update(ep)
                episode_rows.append(row)
        else:
            episode_rows.append({
                "City": city,
                "Episode No.": "",
                "Start Date": "No episode detected",
                "End Date": "",
                "Duration (months)": "",
                "Peak BSADF": "",
                "Peak Date": "",
            })

        city_df = pd.DataFrame({
            "Date": dates,
            "BSADF": bsadf,
            "Critical_95": critical
        })
        city_df.to_csv(out_dir / f"{city}_psy_series.csv", index=False)
        save_city_plot(out_dir / f"{city}_psy_plot.png", city, dates, bsadf, critical)

    pd.DataFrame(summary_rows).to_csv(out_dir / "PSY_summary_table.csv", index=False)
    pd.DataFrame(episode_rows).to_csv(out_dir / "PSY_episode_dating_table.csv", index=False)

    # Write Excel workbook
    xlsx_path = out_dir / "PSY_results.xlsx"
    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        pd.DataFrame(summary_rows).to_excel(writer, sheet_name="Summary", index=False)
        pd.DataFrame(episode_rows).to_excel(writer, sheet_name="Episode Dating", index=False)
        for city, res in results.items():
            city_df = pd.DataFrame({
                "Date": df["Date"],
                "BSADF": res["bsadf"],
                "Critical_95": res["critical"]
            })
            city_df.to_excel(writer, sheet_name=city[:31], index=False)

    return xlsx_path


# -----------------------------
# GUI
# -----------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("860x640")
        self.resizable(True, True)

        self.file_var = tk.StringVar()
        self.out_var = tk.StringVar(value=str(Path.cwd() / "psy_output"))
        self.sim_var = tk.StringVar(value="1000")
        self.seed_var = tk.StringVar(value="42")
        self.lag_var = tk.StringVar(value="0")
        self.min_duration_var = tk.StringVar(value="3")
        self.window_mode_var = tk.StringVar(value="formula")
        self.manual_window_var = tk.StringVar(value="26")

        self._build_ui()

    def _build_ui(self):
        pad = {"padx": 8, "pady": 6}

        frm = ttk.Frame(self)
        frm.pack(fill="both", expand=True, padx=12, pady=12)

        ttk.Label(frm, text="Input price file (Excel or CSV; must contain Year, Month, city columns):").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(frm, textvariable=self.file_var, width=80).grid(row=1, column=0, sticky="we", **pad)
        ttk.Button(frm, text="Browse", command=self.browse_file).grid(row=1, column=1, **pad)

        ttk.Label(frm, text="Output folder:").grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(frm, textvariable=self.out_var, width=80).grid(row=3, column=0, sticky="we", **pad)
        ttk.Button(frm, text="Browse", command=self.browse_out).grid(row=3, column=1, **pad)

        options = ttk.LabelFrame(frm, text="PSY settings")
        options.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=8, pady=12)

        ttk.Label(options, text="Monte Carlo simulations:").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(options, textvariable=self.sim_var, width=12).grid(row=0, column=1, sticky="w", **pad)

        ttk.Label(options, text="Random seed:").grid(row=0, column=2, sticky="w", **pad)
        ttk.Entry(options, textvariable=self.seed_var, width=12).grid(row=0, column=3, sticky="w", **pad)

        ttk.Label(options, text="ADF lag length (fixed):").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(options, textvariable=self.lag_var, width=12).grid(row=1, column=1, sticky="w", **pad)

        ttk.Label(options, text="Minimum episode duration (months):").grid(row=1, column=2, sticky="w", **pad)
        ttk.Entry(options, textvariable=self.min_duration_var, width=12).grid(row=1, column=3, sticky="w", **pad)

        ttk.Label(options, text="Minimum window:").grid(row=2, column=0, sticky="w", **pad)
        ttk.Radiobutton(options, text="Use formula r0 = 0.01 + 1.8/sqrt(T)", variable=self.window_mode_var, value="formula").grid(row=2, column=1, columnspan=3, sticky="w", **pad)
        ttk.Radiobutton(options, text="Use manual months", variable=self.window_mode_var, value="manual").grid(row=3, column=1, sticky="w", **pad)
        ttk.Entry(options, textvariable=self.manual_window_var, width=12).grid(row=3, column=2, sticky="w", **pad)

        ttk.Label(frm, text="Progress:").grid(row=5, column=0, sticky="w", **pad)
        self.progress = ttk.Progressbar(frm, orient="horizontal", mode="determinate")
        self.progress.grid(row=6, column=0, columnspan=2, sticky="we", padx=8, pady=6)

        self.log = tk.Text(frm, height=18, wrap="word")
        self.log.grid(row=7, column=0, columnspan=2, sticky="nsew", padx=8, pady=8)

        frm.columnconfigure(0, weight=1)
        frm.rowconfigure(7, weight=1)

        ttk.Button(frm, text="Run PSY Analysis", command=self.run_thread).grid(row=8, column=0, sticky="w", padx=8, pady=10)
        ttk.Button(frm, text="Open Output Folder", command=self.open_out).grid(row=8, column=1, sticky="e", padx=8, pady=10)

    def browse_file(self):
        path = filedialog.askopenfilename(filetypes=[("Excel/CSV files", "*.xlsx *.xls *.csv"), ("All files", "*.*")])
        if path:
            self.file_var.set(path)

    def browse_out(self):
        path = filedialog.askdirectory()
        if path:
            self.out_var.set(path)

    def open_out(self):
        out = Path(self.out_var.get())
        out.mkdir(parents=True, exist_ok=True)
        try:
            import subprocess, platform
            system = platform.system()
            if system == "Darwin":
                subprocess.call(["open", str(out)])
            elif system == "Windows":
                os.startfile(str(out))  # type: ignore[attr-defined]
            else:
                subprocess.call(["xdg-open", str(out)])
        except Exception as e:
            messagebox.showinfo(APP_TITLE, f"Output folder: {out}\n\nCould not open automatically: {e}")

    def append_log(self, text):
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.update_idletasks()

    def set_progress(self, done, total):
        self.progress["maximum"] = total
        self.progress["value"] = done
        self.update_idletasks()

    def run_thread(self):
        thread = threading.Thread(target=self.run_analysis, daemon=True)
        thread.start()

    def run_analysis(self):
        try:
            self.log.delete("1.0", "end")
            file_path = self.file_var.get().strip()
            out_dir = Path(self.out_var.get().strip())

            if not file_path:
                raise ValueError("Please choose an input file.")

            simulations = int(self.sim_var.get())
            seed = int(self.seed_var.get())
            lags = int(self.lag_var.get())
            min_duration = int(self.min_duration_var.get())

            self.append_log("Loading input file...")
            df = load_price_file(file_path)

            city_cols = [c for c in df.columns if c not in ["Year", "Month", "Date"]]
            if not city_cols:
                raise ValueError("No city columns detected. Please include at least one city price column.")

            T = len(df)
            if self.window_mode_var.get() == "formula":
                r0 = 0.01 + 1.8 / math.sqrt(T)
                min_window = int(math.floor(r0 * T))
                self.append_log(f"Using formula-based minimum window: r0 = 0.01 + 1.8/sqrt(T) = {r0:.4f}")
                self.append_log(f"T = {T}, so r0 * T = {r0*T:.2f}, minimum window = {min_window} months (floor rule)")
            else:
                min_window = int(self.manual_window_var.get())
                self.append_log(f"Using manual minimum window: {min_window} months")

            self.append_log("Preparing series and running Monte Carlo simulations...")
            results = {}

            total_steps = len(city_cols) * (simulations + 1)
            done_steps = 0
            self.set_progress(0, total_steps)

            for city in city_cols:
                self.append_log(f"\nProcessing city: {city}")
                log_price = preprocess_series(df[city])
                bsadf = compute_bsadf(log_price, min_window=min_window, lags=lags)
                done_steps += 1
                self.set_progress(done_steps, total_steps)

                def local_progress(i, total):
                    nonlocal done_steps
                    base = total_steps - (len(city_cols) - city_cols.index(city)) * (simulations + 1)
                    self.set_progress(base + i + 1, total_steps)

                critical = monte_carlo_critical_values(
                    T=len(log_price),
                    min_window=min_window,
                    lags=lags,
                    simulations=simulations,
                    seed=seed,
                    progress_cb=local_progress
                )

                results[city] = {
                    "bsadf": bsadf,
                    "critical": critical,
                    "min_window": min_window,
                    "lags": lags,
                    "simulations": simulations,
                    "min_duration": min_duration,
                }

            self.append_log("\nWriting outputs...")
            xlsx_path = write_outputs(df, results, out_dir)

            self.append_log(f"Done. Results saved to:\n{out_dir}")
            self.append_log(f"Excel workbook: {xlsx_path.name}")
            self.append_log("Created files:")
            self.append_log("- PSY_summary_table.csv")
            self.append_log("- PSY_episode_dating_table.csv")
            self.append_log("- One CSV and one plot per city")
            self.append_log("- PSY_results.xlsx")
            messagebox.showinfo(APP_TITLE, f"Analysis complete.\n\nOutput folder:\n{out_dir}")

        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Error:\n{e}")
            self.append_log(f"ERROR: {e}")


if __name__ == "__main__":
    app = App()
    app.mainloop()
